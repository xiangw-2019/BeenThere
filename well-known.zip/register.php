<?php

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$username = $password = $confirm_password=$birth=$city="";
$username_error = $password_error =$confirm_password_error=$birth_error=$city_error = "";
if($_SERVER["REQUEST_METHOD"]=="POST"){
   
    //username
    if(empty(trim($_POST["username"]))){
        $username_error = "Empty username!";
         echo trim($_POST["username"]);
    }
    else{
        $username = trim($_POST["username"]);
         $sql_query = "SELECT uid FROM users Where username = '$username'";
         
        $result = mysqli_query($link, $sql_query);
        if($row = mysqli_fetch_array($result)){
           
           $username_error = "Duplicate username";
        }
        
       
    }

    //password
    if(empty(trim($_POST["password"]))){
        $password_error = "Empty password";
    }
    elseif(strlen(trim($_POST["password"]))<5){
        $password_error = "password too short";
    }
    else{
        $password = trim($_POST["password"]);
    }

    //confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_error = "Empty confirm_password";
    }
    else{
        $confirm_password = trim($_POST["confirm_password"]);
    }

    if($password!=$confirm_password){
        $confirm_password_error = "Password does not match";
    }
    
    if(empty($username_error) && empty($password_error) && empty($confirm_password_error)){
        $city = trim($_POST["city"]);
        $birth = trim($_POST["birth"]);
        $sql_query = "INSERT INTO users (username, password,City,Age) VALUES ('$username', '$password','$city','$birth')";
        if(mysqli_query($link, $sql_query)){
        
                $sqll_query = "SELECT uid FROM users Where username = '$username' AND password = '$password'";
        $result = mysqli_query($link, $sqll_query);
        
        if($row = mysqli_fetch_array($result)){
           session_start();
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $row['uid'];
            $_SESSION["username"] = $username;                            
           
           
        }
        header("Location:recadd.php");

        exit;    
        }
            
        
        
        
    }
    mysqli_stmt_close($link);

}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Bootstrap Admin Theme v3</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="login-bg">
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-12">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="index.html">Signup</a></h1>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>

	<div class="page-content container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="login-wrapper">
			        <div class="box">
			            <div class="content-wrap">
											<h6>Sign Up</h6>
											<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_error)) ? 'has-error' : ''; ?>">
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_error; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($password_error)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control" value="<?php echo $password; ?>">
                <span class="help-block"><?php echo $password_error; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($confirm_password_error)) ? 'has-error' : ''; ?>">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>">
                <span class="help-block"><?php echo $confirm_password_error; ?></span>
            </div>
            
            
<!--////////////////////new add-->
            <div class="form-group <?php echo (!empty($birth_error)) ? 'has-error' : ''; ?>">
                <label>Age</label>
                <input type="text" name="birth" class="form-control" value="<?php echo $birth; ?>">
                <span class="help-block"><?php echo $birth_error; ?></span>
            </div>     
            
            
            <div class="form-group <?php echo (!empty($city_error)) ? 'has-error' : ''; ?>">
                <label>City</label>
                <input type="text" name="city" class="form-control" value="<?php echo $city; ?>">
                <span class="help-block"><?php echo $city_error; ?></span>
            </div> 
            
            
<!--////////////////////new add-->
            
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
										
			                </div>                
			            </div>
			        </div>

			       
			    </div>
			</div>
		</div>
	</div>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>