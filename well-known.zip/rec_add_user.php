<!-- part1: add user information to the Database-->
<!-- create database "users" with "id" and "username"-->
<?php
include("rec_header.php");
include("rec_db.php");

      $flag=0;
      if(isset($_POST['submit'])) {
        $result=mysqli_query($con,"insert into recUser(username)values('$_POST[username]')");
        if($result) {
          $flag=1;
        }
      }
 ?>

 <div class="panel panel-default">

   <div class="panel-heading">
     <h2>
       <a class="btn btn-success" href="rec_add_destinations.php"> Add Destinations </a>
       <a class="btn btn-info pull-right" href="rec_index.php"> Back </a>
     </h2>
   </div>

   <?php if($flag) { ?>
     <div class="alert alert-success">User Successfully Inserted in the Database </div>
   <?php } ?>

   <div class="panel-body">
     <form action="rec_add_user.php" method="post">

       <div class="form-group">
         <label for="username">User Name</label>
         <input type="text" name="username" id="username" class="form-control" required>
       </div>

       <div class="form-group">
         <input type="submit" name="submit" value="submit" class="btn btn-primary" required>
       </div>

     </form>

   </div>

 </div>
