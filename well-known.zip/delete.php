<?
$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$id=$_REQUEST["id"];
$sql = "Delete from articles WHERE id='$id'";

if (mysqli_query($link, $sql)) {
   
header( "Location:explore.php" );
exit;
} else {
    echo "Error updating record2: " . mysqli_error($conn);
}

mysqli_close($conn);?>