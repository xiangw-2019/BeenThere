<!-- part3: users submit dest&rating -->
<!-- create database "user_destinations" with id, user_id, dest_name, dest_rating-->
<?php
       session_start();
    //   echo(a);
    //   echo($_GET['id']);
    //   echo($_SESSION['id']);
    //   echo(a);
      if(isset($_GET['id'])) {
        $_SESSION['id']=$_GET['id'];
        
      }
    //   echo(a);
    //   echo($_GET['id']);
    //   echo($_SESSION['id']);
    //   echo($temp);
      include("rec_header.php");
      include("rec_db.php");
     $temp=intval( $_SESSION['id']);
      $flag=0;
    //   echo($temp);

      if(isset($_POST['submit'])) {
        $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$temp','$_POST[dest_name]','$_POST[dest_rating]')");
        if($result) {
          $flag=1;
        }
      }
 ?>

<!-- Pay attention to the name of table and files, check if consistent-->

 <div class="panel panel-default">

   <div class="panel-heading">
     <h2>
       <!--<a class="btn btn-success" href="rec_add_destinations.php"> Add Destinations </a>-->
       <a class="btn btn-info pull-right" href="dashboard.php"> Back </a>
       <br>
     </h2>
   </div>

   <?php if($flag) { ?>
     <div class="alert alert-success">Destinations Successfully Inserted in the Database </div>
   <?php } ?>

   <div class="panel-body">

     <form action="" method="post">

       <div class="form-group">
         <label for="username">Destination Name</label>
         <input type="text" name="dest_name" id="dest_name" class="form-control" required>
       </div>

       <div class="form-group">
         <label for="username">Destination Rating</label>
         <input type="number" name="dest_rating" id="dest_rating" class="form-control" required>
       </div>

       <div class="form-group">
         <input type="submit" name="submit" value="submit" class="btn btn-primary" required>
       </div>

     </form>

   </div>

 </div>
