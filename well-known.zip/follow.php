<?
$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$ee=$_REQUEST["er"];
$er=$_REQUEST["ee"];
$sql1 = "SELECT uid FROM user_relation WHERE uid = $ee AND friend_id = $er";
$result1 = mysqli_query($link, $sql1);
if($Row=mysqli_fetch_array($result1)){
    $message = "Already Followed";
    echo "<script type='text/javascript'>alert('$message');</script>";
      
}
else{
$sql = "INSERT INTO user_relation (relation_id, uid, friend_id) VALUES (NULL,'$ee', '$er')";

if (mysqli_query($link, $sql)) {
   
header( "Location:explore.php" );
exit;
} else {
    echo "Error updating record2: " . mysqli_error($link);
}
}
mysqli_close($link);


?>


<!DOCTYPE html>
<html>
 <form action='explore.php?ee=". $row['shouldFollow'] . "&er=". $user_id ."', method='post'>
 		  	  		  	 <button type='submit' class='btn btn-warning btn-sm'>Go Back</button>
 		  	 </form>
 		  	 
 		  	 
</html>