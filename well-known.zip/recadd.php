<?php
       session_start();
    include("rec_db.php");
$user_id = 0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
   
}
$dest1="Chicago";
$dest2="New York";
$dest3="Los Angeles";
$dest4="Huston";
$dest5="Seatle";
$dest6="Urbana-Champaign";
$dest7="Boston";
$dest8="Atlanta";
$dest9="Miami";
$dest10="Denver";
$dest11="Beijing";
$dest12="Shanghai";
$dest13="Guangzhou";
$dest14="Shenzhen";
$dest15="Sydney";
$dest16="Tokyo";
$dest17="London";
$dest18="Bangkok";
$dest19="Paris";
$dest20="Rome";

      if(isset($_POST['submit'])) {
        if($_POST[a1]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest1','$_POST[a1]')");
        }
        if($_POST[a2]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest2','$_POST[a2]')");
        }
        if($_POST[a3]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest3','$_POST[a3]')");
        }
        if($_POST[a4]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest4','$_POST[a4]')");
        }
        if($_POST[a5]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest5','$_POST[a5]')");
        }
        if($_POST[a6]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest6','$_POST[a6]')");
        }
        if($_POST[a7]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest7','$_POST[a7]')");
        }
        
        if($_POST[a8]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest8','$_POST[a8]')");
        }
        if($_POST[a9]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest9','$_POST[a9]')");
        }
        
        if($_POST[a10]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest10','$_POST[a10]')");
        }
        if($_POST[a11]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest11','$_POST[a11]')");
        }
        if($_POST[a12]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest12','$_POST[a12]')");
        }
        if($_POST[a13]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest13','$_POST[a13]')");
        }
        if($_POST[a14]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest14','$_POST[a14]')");
        }
        if($_POST[a15]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest15','$_POST[a15]')");
        }
        if($_POST[a16]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest16','$_POST[a16]')");
        }
        if($_POST[a17]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest17','$_POST[a17]')");
        }
        
        if($_POST[a18]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest18','$_POST[a18]')");
        }
        if($_POST[a19]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest19','$_POST[a19]')");
        }
        
        if($_POST[a20]!=0){
                    $result=mysqli_query($con,"insert into user_destinations(user_id,dest_name,dest_rating)values('$user_id','$dest20','$_POST[a20]')");
        }

         header("location: dashboard.php"); 
        
      }
     

 ?>





<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.slidecontainer {
  width: 100%;
}

.slider {
  -webkit-appearance: none;
  width: 50%;
  height: 5px;
  border-radius: 15px;
  background: #d3d3d3;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}

.slider:hover {
  opacity: 1;
}

.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 15px;
  height: 15px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
}

.slider::-moz-range-thumb {
  width: 15px;
  height: 15px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
}
</style>
</head>
<body>

<h1 align="center">Destination Rating</h1>

<p align="center">Please only rate the recommendation level for the destination you have been to.</p>
<br>

<!----------------------------------------------------- -->
<div class="mybody">
    <form action="" method="post">
<div class="""slidecontainer" style="text-align: center">
Chicago
  <input type="range" name="a1" min="0" max="100" value="0" class="slider" id="myRange">
  Value: <span id="demo"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
New York
  <input type="range" name="a2" min="0" max="100" value="0" class="slider" id="myRange1">
  Value: <span id="demo1"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Los Angeles
  <input type="range"  name="a3" min="0" max="100" value="0" class="slider" id="myRange2">
  Value: <span id="demo2"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Huston
  <input type="range" name="a4"  min="0" max="100" value="0" class="slider" id="myRange3">
  Value: <span id="demo3"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Seatle
  <input type="range"  name="a5" min="0" max="100" value="0" class="slider" id="myRange4">
  Value: <span id="demo4"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Urbana-Champaign
  <input type="range" name="a6"  min="0" max="100" value="0" class="slider" id="myRange5">
  Value: <span id="demo5"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Boston
  <input type="range" name="a7"  min="0" max="100" value="0" class="slider" id="myRange6">
  Value: <span id="demo6"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Atlanta
  <input type="range"  name="a8" min="0" max="100" value="0" class="slider" id="myRange7">
  Value: <span id="demo7"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Miami
  <input type="range"  name="a9" min="0" max="100" value="0" class="slider" id="myRange8">
  Value: <span id="demo8"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Denver
  <input type="range" name="a10"  min="0" max="100" value="0" class="slider" id="myRange9">
  Value: <span id="demo9"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Beijing
  <input type="range"  name="a11" min="0" max="100" value="0" class="slider" id="myRange10">
  Value: <span id="demo10"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Shanghai
  <input type="range"  name="a12" min="0" max="100" value="0" class="slider" id="myRange11">
  Value: <span id="demo11"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Guangzhou
  <input type="range" name="a13"  min="0" max="100" value="0" class="slider" id="myRange12">
  Value: <span id="demo12"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Shenzhen
  <input type="range"  name="a14" min="0" max="100" value="0" class="slider" id="myRange13">
  Value: <span id="demo13"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Sydney
  <input type="range"  name="a15" min="0" max="100" value="0" class="slider" id="myRange14">
  Value: <span id="demo14"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Tokyo
  <input type="range"  name="a16" min="0" max="100" value="0" class="slider" id="myRange15">
  Value: <span id="demo15"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
London
  <input type="range"  name="a17" min="0" max="100" value="0" class="slider" id="myRange16">
  Value: <span id="demo16"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Bangkok
  <input type="range"  name="a18" min="0" max="100" value="0" class="slider" id="myRange17">
  Value: <span id="demo17"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Paris
  <input type="range" name="a19"  min="0" max="100" value="0" class="slider" id="myRange18">
  Value: <span id="demo18"></span>
</div>

<br>

<div class="""slidecontainer" style="text-align: center">
Rome
  <input type="range"  name="a20" min="0" max="100" value="0" class="slider" id="myRange19">
  Value: <span id="demo19"></span>
</div>
</div>
<br>

<!----------------------------------------------------- -->

<script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
</script>

<script>
var slider1 = document.getElementById("myRange1");
var output1 = document.getElementById("demo1");
output1.innerHTML = slider1.value;

slider1.oninput = function() {
  output1.innerHTML = this.value;
}
</script>

<script>
var slider2 = document.getElementById("myRange2");
var output2 = document.getElementById("demo2");
output2.innerHTML = slider2.value;

slider2.oninput = function() {
  output2.innerHTML = this.value;
}
</script>

<script>
var slider3 = document.getElementById("myRange3");
var output3 = document.getElementById("demo3");
output3.innerHTML = slider3.value;

slider3.oninput = function() {
  output3.innerHTML = this.value;
}
</script>

<script>
var slider4 = document.getElementById("myRange4");
var output4 = document.getElementById("demo4");
output4.innerHTML = slider4.value;

slider4.oninput = function() {
  output4.innerHTML = this.value;
}
</script>

<script>
var slider5 = document.getElementById("myRange5");
var output5 = document.getElementById("demo5");
output5.innerHTML = slider5.value;

slider5.oninput = function() {
  output5.innerHTML = this.value;
}
</script>

<script>
var slider6 = document.getElementById("myRange6");
var output6 = document.getElementById("demo6");
output6.innerHTML = slider6.value;

slider6.oninput = function() {
  output6.innerHTML = this.value;
}
</script>

<script>
var slider7 = document.getElementById("myRange7");
var output7 = document.getElementById("demo7");
output7.innerHTML = slider7.value;

slider7.oninput = function() {
  output7.innerHTML = this.value;
}
</script>

<script>
var slider8 = document.getElementById("myRange8");
var output8 = document.getElementById("demo8");
output8.innerHTML = slider8.value;

slider8.oninput = function() {
  output8.innerHTML = this.value;
}
</script>

<script>
var slider9 = document.getElementById("myRange9");
var output9 = document.getElementById("demo9");
output9.innerHTML = slider9.value;

slider9.oninput = function() {
  output9.innerHTML = this.value;
}
</script>

<script>
var slider10 = document.getElementById("myRange10");
var output10 = document.getElementById("demo10");
output10.innerHTML = slider10.value;

slider10.oninput = function() {
  output10.innerHTML = this.value;
}
</script>

<script>
var slider11 = document.getElementById("myRange11");
var output11 = document.getElementById("demo11");
output11.innerHTML = slider11.value;

slider11.oninput = function() {
  output11.innerHTML = this.value;
}
</script>

<script>
var slider12 = document.getElementById("myRange12");
var output12 = document.getElementById("demo12");
output12.innerHTML = slider12.value;

slider12.oninput = function() {
  output12.innerHTML = this.value;
}
</script>

<script>
var slider13 = document.getElementById("myRange13");
var output13 = document.getElementById("demo13");
output13.innerHTML = slider13.value;

slider13.oninput = function() {
  output13.innerHTML = this.value;
}
</script>

<script>
var slider14 = document.getElementById("myRange14");
var output14 = document.getElementById("demo14");
output14.innerHTML = slider14.value;

slider14.oninput = function() {
  output14.innerHTML = this.value;
}
</script>

<script>
var slider15 = document.getElementById("myRange15");
var output15 = document.getElementById("demo15");
output15.innerHTML = slider15.value;

slider15.oninput = function() {
  output15.innerHTML = this.value;
}
</script>

<script>
var slider16 = document.getElementById("myRange16");
var output16 = document.getElementById("demo16");
output16.innerHTML = slider16.value;

slider16.oninput = function() {
  output16.innerHTML = this.value;
}
</script>

<script>
var slider17 = document.getElementById("myRange17");
var output17 = document.getElementById("demo17");
output17.innerHTML = slider17.value;

slider17.oninput = function() {
  output17.innerHTML = this.value;
}
</script>

<script>
var slider18 = document.getElementById("myRange18");
var output18 = document.getElementById("demo18");
output18.innerHTML = slider18.value;

slider18.oninput = function() {
  output18.innerHTML = this.value;
}
</script>

<script>
var slider19 = document.getElementById("myRange19");
var output19 = document.getElementById("demo19");
output19.innerHTML = slider19.value;

slider19.oninput = function() {
  output19.innerHTML = this.value;
}
</script>
<!----------------------------------------------------- -->

<div class="buttonHolder" style="text-align: center">
<input type="submit" name= "submit" value="Submit">
</div>

<button><a href="dashboard.php"> Back to dashboard</a></button>

</body>
</html>