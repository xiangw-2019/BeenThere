<?php
session_start();
$user_id = 0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
   
}

$id=$_REQUEST["id"];

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


$sql = "DELETE FROM user_relation Where uid = '$user_id' AND friend_id = '$id'";

$result_1 = mysqli_query($link, $sql);

if($row_1 = mysqli_fetch_array($result_1))
{  
    
}
header("location: profile.php");

?>