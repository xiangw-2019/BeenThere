<!-- part8: copy from rec_header.php to set the layout -->
<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"> </script>

<!-- Latest compiled Javascript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"> </script>

<head>

<div class="container">

  <h2><div class = "well text-center"> Recommendation For You: </div></h2>
<!------------------------------------------------------------------------------->

<!-- part5:create a matrix from rating database-->
<?php
include("rec_db.php");
include("rec_recommend.php");

$destinations=mysqli_query($con,"select * from user_destinations");

$matrix=array();

while($destination=mysqli_fetch_array($destinations)) {
  $users=mysqli_query($con,"select username from users where uid=$destination[user_id]");
  $username=mysqli_fetch_array($users);
  $matrix[$username['username']][$destination['dest_name']]=$destination['dest_rating'];
}

//to show the matrix
// echo "<pre>";
// print_r($matrix);
// echo "</pre>";

// //part8: show recommendation list for every users
$users=mysqli_query($con,"select username from users where uid=$_GET[id]");
$username=mysqli_fetch_array($users);

getRecommendation($matrix,$username['username']);//move below in part8, set the layout

// //part6 //part7: get recommendation for one user e.g. Alice
// var_dump(getRecommendation($matrix,"Jerry"));

?>

<!------------------------------------------------------------------------------->

<!-- part8: copy from show_destinations, set the layout-->
<div class="panel panel-default">

  <div class="panel-heading">
    <h2>
      <!--<a class="btn btn-success" href="rec_add_user.php">  </a>-->
      <a class="btn btn-info pull-right" href="dashboard.php"> Back </a>
      <br>
    </h2>
  </div>

  <div class="panel-body">
    <table class="table table-striped">
      <th> Destination Name </th>
      <th> Destination Rating</th>

      <!--insert the username from Database-->
      <?php
      $recommendation=array();
      $recommendation=getRecommendation($matrix,$username['username']);
      foreach($recommendation as $destination=>$rating) {?>
        <tr>
          <td> <?php echo $destination; ?> </td>
          <td> <?php echo $rating; ?> </td>
        </tr>
      <?php } ?>

    </table>
  </div>

</div>


