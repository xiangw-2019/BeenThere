<!--part4: build show destinations database, copy from rec_index.php-->
<?php
include("rec_header.php");
include("rec_db.php");
?>

<div class="panel panel-default">

  <div class="panel-heading">
    <h2>
      <!--<a class="btn btn-success" href="rec_add_user.php"> Add Users </a>-->
      <a class="btn btn-info pull-right" href="dashboard.php"> Back </a>
      <br>
    </h2>
  </div>

  <!--part3:-->
  <div class="panel-body">
    <table class="table table-striped">
      <th> Destination Name </th>
      <th> Destination Rating</th>

      <!--insert the username from Database-->
      <?php $result=mysqli_query($con,"select * from user_destinations where user_id='$_GET[id]'");
      while($row=mysqli_fetch_array($result)) {?>
        <tr>
          <td> <?php echo $row['dest_name']; ?> </td>
          <td> <?php echo $row['dest_rating']; ?> </td>
        </tr>
      <?php } ?>

    </table>
  </div>

</div>
