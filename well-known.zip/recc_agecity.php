<?php
include("rec_db.php");
$destinations=mysqli_query($con,"select * from user_destinations natural join users");
$matrix1=array();
$matrix2=array();
while($destination=mysqli_fetch_array($destinations)) {
  $users=mysqli_query($con,"select username from users where Age=$destination[Age]");
  $username=mysqli_fetch_array($users);
  $matrix1[$username['username']][$destination['dest_name']]=$destination['dest_rating'];
}
while($destination=mysqli_fetch_array($destinations)) {
  $users=mysqli_query($con,"select username from users where Age=$destination[Age]");
  $username=mysqli_fetch_array($users);
  $matrix2[$username['username']][$destination['dest_name']]=$destination['dest_rating'];
}
//use Euclidean Distance to get the similarity_distance
function similarity_distance($matrix,$person1,$person2) {
  $similar=array();
  $sum=0;

  foreach($matrix[$person1] as $key=>$value) {
    //check if the key exists in both people
    if(array_key_exists($key,$matrix[$person2])) {
      $similar[$key]=1;
    }
  }

  if($similar==0) {
    //no similarity
    return 0;
  }

  foreach($matrix[$person1] as $key=>$value) {
    if(array_key_exists($key,$matrix[$person2])) {
      $sum=$sum+pow($value-$matirx[$person2][$key],2);
    }
  }
    //return normalized value
  return 1/(1+sqrt($sum));
}

//part7: implementation for getRecommendation
//return a list of recommendation for a selected person
function getCityRecommendation($matrix2,$person) {
  $total=array();
  $simsums=array();//summation of all the similatries
  $ranks=array();

  foreach($matrix as $otherPerson=>$value) {
    if($otherPerson!=$person) {//user doesn't have similarity with himself
      $sim=similarity_distance($matrix,$person,$otherPerson);
       //var_dump($sim);
       foreach($matrix[$otherPerson] as $key=>$value) {

        // check if key doesn't exist in the matrix[$person]
        if(!array_key_exists($key,$matrix[$person])) {
          if(!array_key_exists($key,$total)) {
            $total[$key]=0;//define initail value
          }
          //calculate the numerator part
          $total[$key]+=$matrix[$otherPerson][$key]*$sim;
          //$matrix[$otherPerson][$key] is rating $otherPerson made on the same movie

          if(!array_key_exists($key,$simsums)) {
            $simsums[$key]=0;//define initial value
          }
          //calculate the denominator part
          $simsums[$key]+=$sim;
        }
      }
    }
  }

  foreach($total as $key=>$value) {
    $ranks[$key]=$value/$simsums[$key];//calculate numerator/denominator
  }
  array_multisort($ranks,SORT_DESC);
  return $ranks;
}
function getAgeRecommendation($matrix1,$person) {
  $total=array();
  $simsums=array();//summation of all the similatries
  $ranks=array();

  foreach($matrix as $otherPerson=>$value) {
    if($otherPerson!=$person) {//user doesn't have similarity with himself
      $sim=similarity_distance($matrix,$person,$otherPerson);
       //var_dump($sim);
       foreach($matrix[$otherPerson] as $key=>$value) {

        // check if key doesn't exist in the matrix[$person]
        if(!array_key_exists($key,$matrix[$person])) {
          if(!array_key_exists($key,$total)) {
            $total[$key]=0;//define initail value
          }
          //calculate the numerator part
          $total[$key]+=$matrix[$otherPerson][$key]*$sim;
          //$matrix[$otherPerson][$key] is rating $otherPerson made on the same movie

          if(!array_key_exists($key,$simsums)) {
            $simsums[$key]=0;//define initial value
          }
          //calculate the denominator part
          $simsums[$key]+=$sim;
        }
      }
    }
  }

  foreach($total as $key=>$value) {
    $ranks[$key]=$value/$simsums[$key];//calculate numerator/denominator
  }
  array_multisort($ranks,SORT_DESC);
  return $ranks;
}
function getAllRecommendation() {
  $overall=getRecommendation($matirx,$person);
  $agerating=getAgeRecommendation($matirx1,$person);
  $cityrating=getCityRecommendation($matirx2,$person);
  return 0.5*$overall+0.25*$agerating+0.25*$cityrating;
}
?>
