<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

session_start();
$user_id = 0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
   
}

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$site = mysqli_real_escape_string($link, $_REQUEST['Site']);
$title = mysqli_real_escape_string($link, $_REQUEST['Title']);
$body = mysqli_real_escape_string($link, $_REQUEST['body']);
 
// attempt insert query execution
$sql = "INSERT INTO articles (user_id,title, body, site) VALUES ('$user_id','$title','$body', '$site')";
if(mysqli_query($link, $sql)){
    //echo "Records added successfully.";
ob_start(); // ensures anything dumped out will be caught

// do stuff here
$url = 'http://beenthere.web.illinois.edu/New.php'; // this can be set based on whatever

// clear out the output buffer
while (ob_get_status()) 
{
    ob_end_clean();
}

// no redirect
header( "Location:explore.php" );
exit;
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>