<?php

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
session_start();
$user_id =0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
   
}
$to_id=$_REQUEST["id"];
if(!$to_id){
  header("location: sentmessage.php");
}

   $sql5= "SELECT username FROM users WHERE uid ='$to_id' ";
   $result5 = mysqli_query($link, $sql5);
    $Row5=mysqli_fetch_array($result5);
    $temp=$Row5['username'];
    


   
  ?>
	
<!DOCTYPE html>
<html>
  <head>
    <title>BeenThere</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="dashboard.php">BeenThere</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">

	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $user_name ?> <b class="caret"></b></a>
	                        <ul class="dropdown-menu animated fadeInUp">
	                          <li><a href="profile.php">Profile</a></li>
	   
	                          <li><a href="logout.php">Logout</a></li>
	                        </ul>
	                      </li>
	                    </ul>
	                  </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="dashboard.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    <li><a href="New.php"><i class="glyphicon glyphicon-calendar"></i> New Post</a></li>
                    <li><a href="explore.php"><i class="glyphicon glyphicon-calendar"></i> Explore</a></li>
                    <li><a href="advance.php"><i class="glyphicon glyphicon-calendar"></i> Advance</a></li>
                    <li><a href="search.php"><i class="glyphicon glyphicon-calendar"></i> Search Result</a></li>
                    <li><a href="update.php"><i class="glyphicon glyphicon-calendar"></i> Update</a></li>
                    <li><a href="myArticle.php"><i class="glyphicon glyphicon-calendar"></i> My Article</a></li>

                    <!--  original code
                    <li><a href="calendar.html"><i class="glyphicon glyphicon-calendar"></i> Calendar</a></li>
                    <li><a href="stats.html"><i class="glyphicon glyphicon-stats"></i> Statistics (Charts)</a></li>
                    <li><a href="tables.html"><i class="glyphicon glyphicon-list"></i> Tables</a></li>
                    <li><a href="buttons.html"><i class="glyphicon glyphicon-record"></i> Buttons</a></li>
                    <li><a href="editors.html"><i class="glyphicon glyphicon-pencil"></i> Editors</a></li>
                    <li><a href="forms.html"><i class="glyphicon glyphicon-tasks"></i> Forms</a></li> -->
                    <li><a href="profile.php"><i class="glyphicon glyphicon-tasks"></i> Following</a></li> 
                     <li><a href="chat.php"><i class="glyphicon glyphicon-tasks"></i> Chat Room</a></li> 
                    
                </ul>
             </div>
		  </div>
		  <?php
		      $sql = "SELECT username,City,Age FROM users Where uid = '$to_id'";
    
    $result = mysqli_query($link, $sql);
    while($row = mysqli_fetch_array($result))
    {  
           
            echo "<div class='col-md-10' style='float:right'>
    		  			<div class='content-box-large'>
    		  				<div class='panel-heading'>
    							<div class='panel-title'>". $row['username'] . "</div>
    						</div>
    		  				<div class='panel-body'>".City.": " 
    		  				 . $row['City'] . "
    		  				</div>
    		  					<div class='panel-body'>".Age.": " 
    		  				 . $row['Age'] . "
    		  				</div>
    		  				<div class='column'>
    </br>
    		  	 <form action='unfollow.php?id=". $value . "', method='post'>
    		  	 <button type='submit' class='btn btn-danger btn-sm'>Unfollow</button>
    		  	 </form>
    		  	 </div>
    
    		  			</div>
    		  		</div>
    		  	
                  ";} ?>
	<!--	  <div class="col-md-9">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title"><p id="p1">User</p></div>
							
							<div class="panel-options">
								<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
								<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
							</div>
						</div>
		  				<div class="panel-body">
		  				<p id="p2">body</p>
		  				</div>
		  			</div>
		  		</div>> -->
<!--
    <footer>
         <div class="container">
         
            <div class="copy text-center">
               Copyright 2014 <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>
-->

<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">

 function success() {
	 if(document.getElementById("textsend").value==="") { 
            document.getElementById('start_button').disabled = true; 
		    document.getElementById('throw').innerHTML= "Message cannot be empty!"
        } else { 
            document.getElementById('start_button').disabled = false;
			
        }
    }
</script>

  


<form  class="form-group block" id="write-area" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	
	<div  class="form-group" id="write-id"  style='float:left'><textarea class="form-control input-lg-18" id="textsend1" rows="1" cols="100"  name="sendtarget" placeholder="Enter Receiver name..."></textarea><textarea class="form-control input-lg-18" id="textsend" rows="4" cols="30" onkeyup="success()" name="sendthis" placeholder="Enter your Message ..."></textarea><button type="submit"  id="start_button" >Send <i class="fa fa-paper-plane"></i></button><p id="throw"></p>
		</div>
	 </form>
	 
<!--<div class="bar">-->
<!--  Navigate to:<a href="sentmessage.php"> Sent Messages</a> | <a href="dashboard.php"> Dashboard</a> | -->
<!--</div> -->


<?php	
$sql2= "SELECT username FROM users WHERE uid ='$user_id' ";
   $result2 = mysqli_query($link, $sql2);
   
    
   if(isset($_POST) & !empty($_POST))  {
	   		$insertmsg = $_POST['sendthis'];  
	   		$inserttarget = $_POST['sendtarget']; 
	   	
	   $Row2=mysqli_fetch_array($result2);
	      		$fname=$Row2["username"];
				 $sql4 = "INSERT INTO `messages`( `user_id`, `to_username`, `text`, `time`, `user_name`) VALUES ('$user_id','$inserttarget','$insertmsg',CURRENT_TIMESTAMP,'$fname');";
				$result4=mysqli_query($link,$sql4); }
 ?>


	


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
       

  </body>
</html>	
