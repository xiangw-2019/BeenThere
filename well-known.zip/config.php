<?php

define('DB_SEVER','localhost:3306');
define('DB_USERNAME','beenthere_root');
define('DB_PASSWORD','CS411_ROOT');
define('DB_NAME','beenthere_test');

$link = mysqli_connect(DB_SEVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($link == false){
    die("ERROR: Connection failed". mysqli_connect_error());
}

?>