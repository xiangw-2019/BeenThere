<!--part2-->
<?php
include("rec_header.php");
include("rec_db.php");
?>

<div class="panel panel-default">

  <div class="panel-heading">
    <h2>
      <!--<a class="btn btn-success" href="rec_add_user.php"> Add Users </a>-->
      <!--<a class="btn btn-info pull-right" href="rec_index.php"> Back </a>-->
    </h2>
  </div>

  <!--part3:-->
  <div class="panel-body">
    <table class="table table-striped">
      <th> User Name </th>
      <th> Add Destinations </th>
      <th> Show Destinations </th>
      <th> Show Recommendation </th>

      <!--insert the username from Database-->
      <?php $result=mysqli_query($con,"select * from users");
      while($row=mysqli_fetch_array($result)) {?>
        <tr>
          <td> <?php echo $row['username']; ?> </td>
          <td>
          <form action="rec_add_destinations.php">
          <input type="submit" name="add_destinations" class="btn btn-primary" value="Add Destinations">
          <input type="hidden" name="id" value="<?php echo $row['uid'] ?>">
          </form>
          </td>

<!-- part4: add show destinations button to each users-->
          <td>
          <form action="rec_show_destinations.php">
          <input type="submit" name="show_destinations" class="btn btn-primary" value="Show Destinations">
          <input type="hidden" name="id" value="<?php echo $row['uid'] ?>">
          </form>
          </td>

<!-- part8: add show recommendation button to each users -->
          <td>
          <form action="rec_user_recommendation.php">
          <input type="submit" name="show_destinations" class="btn btn-primary" value="Show Recommendation">
          <input type="hidden" name="id" value="<?php echo $row['uid'] ?>">
          </form>
          </td>
        </tr>
      <?php } ?>

    </table>
  </div>

</div>
