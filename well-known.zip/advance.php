


<!DOCTYPE html>
<html>
  <head>
    <title>BeenThere</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="index.html">BeenThere</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">

	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">





	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">My Account <b class="caret"></b></a>
	                        <ul class="dropdown-menu animated fadeInUp">
	                          <li><a href="profile.html">Profile</a></li>
	                          <li><a href="login.html">Logout</a></li>
	                        </ul>
	                      </li>
	                    </ul>
	                  </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li ><a href="dashboard.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    <li><a href="New.php"><i class="glyphicon glyphicon-calendar"></i> New Post</a></li>
                    <li><a href="explore.php"><i class="glyphicon glyphicon-calendar"></i> Explore</a></li>
                    <li class="current"><a href="advance.php"><i class="glyphicon glyphicon-calendar"></i> Advance</a></li>
                    <li><a href="search.php"><i class="glyphicon glyphicon-calendar"></i> Search Result</a></li>
                    <li><a href="update.php"><i class="glyphicon glyphicon-calendar"></i> Update</a></li>
                    <li><a href="myArticle.php"><i class="glyphicon glyphicon-calendar"></i> My Article</a></li>
                    <!--  original code
                    <li><a href="calendar.html"><i class="glyphicon glyphicon-calendar"></i> Calendar</a></li>
                    <li><a href="stats.html"><i class="glyphicon glyphicon-stats"></i> Statistics (Charts)</a></li>
                    <li><a href="tables.html"><i class="glyphicon glyphicon-list"></i> Tables</a></li>
                    <li><a href="buttons.html"><i class="glyphicon glyphicon-record"></i> Buttons</a></li>
                    <li><a href="editors.html"><i class="glyphicon glyphicon-pencil"></i> Editors</a></li>




                    <li><a href="forms.html"><i class="glyphicon glyphicon-tasks"></i> Forms</a></li> -->
                    <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-list"></i> Pages
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="login.html">Login</a></li>
                            <li><a href="signup.html">Signup</a></li>
                        </ul>
                    </li>
                </ul>
             </div>
		  </div>
		  <!-- this is the favourtie city -->
<?php
session_start();
$user_id = 2;
$City='urbana';
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
    $City=$_SESSION["City"];
}

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$content = "";


$sql_query = "SELECT site,AVG(Age) as number FROM articles natural Join users WHERE articles.user_id=users.uid Group By site";
// $sql_query ="SELECT site,count(user_id) as number  From articles group by site";
//check how many people been to your city

$result = mysqli_query($link, $sql_query);
echo("Here is the avg age people have been to each city");
echo "<table border='1'>
<tr>
<th>site</th>
<th>number</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['site'] . "</td>";
echo "<td>" . $row['number'] . "</td>";
echo "</tr>";
}
echo "</table>";
  mysqli_close($link);

?>



<!-- this is the youngagefavorite -->
<?php
session_start();
$user_id = 0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
}

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$content = "";


$sql_query = "(SELECT City as site, count(*)as number From users Where Gender='M' Group by City) union (SELECT City as site, count(*)as number From users Where Gender='F' Group by City) " ;
//  age=(SELECT Age from users WHERE user_id = '$user_id') and 
//check how many people been to your city
//SELECT site,count(Age) as number FROM articles natural Join users  Where users.Age=(SELECT Age from users WHERE user_id = '$user_id') and articles.user_id=users.uid Group By site
$result = mysqli_query($link, $sql_query);
echo("Here is the  city gender information calucation");
echo "<table border='1'>
<tr>
<th>site</th>
<th>number</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['site'] . "</td>";
echo "<td>" . $row['number'] . "</td>";
echo "</tr>";
}
echo "</table>";
  mysqli_close($link);

?>


<!--
    <footer>
         <div class="container">

            <div class="copy text-center">
               Copyright 2014 <a href='#'>Website</a>
            </div>

         </div>
      </footer>
-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    <!--<p>-->
    <!--    $num_rows=$result->num_rows;-->
    <!--if($num_rows>0){-->
    <!--  print("<p>.$num_rows . " result(s) found.</p>);-->
    <!--  while($row=$result->fetch_assoc()){-->
    <!--    print("{$row['body']}<br/>");-->
    <!--  }-->
    <!--  $result->free;-->
    <!--}else{ -->
    <!--  print("nothing found!");-->
    <!--}-->
    <!--</p>-->

  </body>
</html>