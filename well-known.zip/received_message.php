<?php

$link = mysqli_connect("localhost:3306", "beenthere_test_user", "test_user123456", "beenthere_cs411demo");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
session_start();
$user_id =0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
   
}

  ?>
	
<?php
session_start();
$user_id = 0;
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    $user_id = $_SESSION["id"];
    $user_name = $_SESSION["username"] ;         
}
else
{header("location: login.php");}

?>


<!--part2-->
<?php
include("rec_db.php");
?>


<!DOCTYPE html>
<html>
  <head>
    <title>BeenThere</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                 <h1><a href="dashboard.php">BeenThere</a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">

	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $user_name ?> <b class="caret"></b></a>
	                        <ul class="dropdown-menu animated fadeInUp">
	                          <li><a href="profile.php">Profile</a></li>
	   
	                          <li><a href="logout.php">Logout</a></li>
	                        </ul>
	                      </li>
	                    </ul>
	                  </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>

    <div class="page-content">
    	<div class="row">
		  <div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li><a href="dashboard.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    <li><a href="New.php"><i class="glyphicon glyphicon-calendar"></i> New Post</a></li>
                    <li><a href="explore.php"><i class="glyphicon glyphicon-calendar"></i> Explore</a></li>
                    <li><a href="search.php"><i class="glyphicon glyphicon-calendar"></i> Search Result</a></li>
                   
                    <li><a href="myArticle.php"><i class="glyphicon glyphicon-calendar"></i> My Article</a></li>

                    <!--  original code
                    <li><a href="calendar.html"><i class="glyphicon glyphicon-calendar"></i> Calendar</a></li>
                    <li><a href="stats.html"><i class="glyphicon glyphicon-stats"></i> Statistics (Charts)</a></li>
                    <li><a href="tables.html"><i class="glyphicon glyphicon-list"></i> Tables</a></li>
                    <li><a href="buttons.html"><i class="glyphicon glyphicon-record"></i> Buttons</a></li>
                    <li><a href="editors.html"><i class="glyphicon glyphicon-pencil"></i> Editors</a></li>
                    <li><a href="forms.html"><i class="glyphicon glyphicon-tasks"></i> Forms</a></li> -->
                    <li><a href="profile.php"><i class="glyphicon glyphicon-tasks"></i> Following</a></li> 
                    <li class="current"><a href="sentmessage.php"><i class="glyphicon glyphicon-tasks"></i> Message Box</a></li> 
                     <li><a href="chat.php"><i class="glyphicon glyphicon-tasks"></i> Chat Room</a></li> 
                     
                    
                </ul>
             </div>
		  </div>
		  
	<!--	  <div class="col-md-9">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title"><p id="p1">User</p></div>
							
							<div class="panel-options">
								<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
								<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
							</div>
						</div>
		  				<div class="panel-body">
		  				<p id="p2">body</p>
		  				</div>
		  			</div>
		  		</div>> -->
<!--
    <footer>
         <div class="container">
         
            <div class="copy text-center">
               Copyright 2014 <a href='#'>Website</a>
            </div>
            
         </div>
      </footer>
-->

 <h2>Received Messages here:</h2>
 
  <form action='sentmessage.php', method='post'>
    		  	 <button type='submit' class='btn btn-danger btn-sm'>Sent Message</button>
    		  	 </form>

<br>



	
<form  id="newchats">

	

  <?php 
  
  	$sql= "SELECT Text,user_name,time,to_username FROM messages WHERE to_username ='$user_name' ORDER BY m_id DESC ";
   $result = mysqli_query($link, $sql);
   
   ?>
  
   <?php if(mysqli_num_rows($result)>0){
    while ($Row=mysqli_fetch_array($result)) {
        echo "<br>";
        echo "<div class='col-md-10' style='float:right'>
 		  			<div class='content-box-large'>
 		  				<div class='panel-heading'>
 							<div class='panel-title'>From: ". $Row['user_name'] . "</div>
 							<div class='panel-title'>To: ". $Row['to_username'] . "</div>
							
 							<div class='panel-options'>
 								<a href='#' data-rel='collapse'><i class='glyphicon glyphicon-refresh'></i></a>
 								<a href='#' data-rel='reload'><i class='glyphicon glyphicon-cog'></i></a>
 							</div>
 						</div>
 		  				<div class='panel-body'>"
 		  				 . $Row['Text'] . "
 		  				</div>
 		  				<div class='column'>
		  	
 </br>
                <div class='panel-body' style='float:right'>
 		  				 Time: ". $Row['time'] . "
 		  				</div>
 		  	 
 		  	 </br>
 		  	 
 		  
 		  	 </div>

 		  			</div>
		  		</div>";
		  		
	}}else{
	echo nl2br("If you're New here, Start Conversation!");
}
    mysqli_close($link);
?>
     
</form>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    
    
    


  </body>
</html>	

